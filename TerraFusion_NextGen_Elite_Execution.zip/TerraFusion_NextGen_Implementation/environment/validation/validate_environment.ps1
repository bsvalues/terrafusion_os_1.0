# TerraFusion Next-Gen Environment Validation Script
# PowerShell script for Windows systems
# Usage: Run in PowerShell as administrator after running init_environment.ps1

Write-Host "--- TerraFusion Next-Gen Environment Validation ---" -ForegroundColor Cyan

$errors = 0

# 1. Validate Node.js version
$nodeVersion = node -v
if ($nodeVersion -lt "v18.0.0") {
    Write-Host "[ERROR] Node.js version must be 18+ (found $nodeVersion)" -ForegroundColor Red
    $errors++
} else {
    Write-Host "[OK] Node.js version $nodeVersion valid."
}

# 2. Validate Docker is running
$dockerInfo = docker info 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Docker is not running or not installed." -ForegroundColor Red
    $errors++
} else {
    Write-Host "[OK] Docker is running."
}

# 3. Validate Python version
$pythonVersion = python --version
if ($pythonVersion -notlike "*3.10*" -and $pythonVersion -notlike "*3.11*" -and $pythonVersion -notlike "*3.12*") {
    Write-Host "[ERROR] Python version must be 3.10+ (found $pythonVersion)" -ForegroundColor Red
    $errors++
} else {
    Write-Host "[OK] Python version $pythonVersion valid."
}

# 4. Validate Tauri CLI
$tauriVersion = tauri --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Tauri CLI is not installed or not in PATH." -ForegroundColor Red
    $errors++
} else {
    Write-Host "[OK] Tauri CLI version $tauriVersion valid."
}

# 5. Validate PostgreSQL
$psqlVersion = psql --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARN] PostgreSQL not found. Some features may not work." -ForegroundColor Yellow
} else {
    Write-Host "[OK] PostgreSQL version $psqlVersion valid."
}

# 6. Validate Redis
$redisVersion = redis-server --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARN] Redis not found. Caching features may not work." -ForegroundColor Yellow
} else {
    Write-Host "[OK] Redis version $redisVersion valid."
}

Write-Host "\n[INFO] Environment validation complete."
if ($errors -eq 0) {
    Write-Host "[SUCCESS] All critical environment checks passed." -ForegroundColor Green
} else {
    Write-Host "[FAILURE] $errors critical errors found. Please resolve before proceeding." -ForegroundColor Red
}

Write-Host "--- End of Validation ---" -ForegroundColor Cyan
