# TerraFusion Next-Gen Environment Initialization Script
# PowerShell script for Windows systems
# Usage: Run in PowerShell as administrator

Write-Host "--- TerraFusion Next-Gen Environment Initialization ---" -ForegroundColor Cyan

# 1. Check Node.js installation
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Node.js is not installed. Please install Node.js 18+ before running this script." -ForegroundColor Red
    exit 1
} else {
    $nodeVersion = node -v
    Write-Host "[OK] Node.js version $nodeVersion detected."
}

# 2. Check Docker installation
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Docker is not installed. Please install Docker Desktop before running this script." -ForegroundColor Red
    exit 1
} else {
    $dockerVersion = docker --version
    Write-Host "[OK] Docker version $dockerVersion detected."
}

# 3. Check Python installation
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Python is not installed. Please install Python 3.10+ before running this script." -ForegroundColor Red
    exit 1
} else {
    $pythonVersion = python --version
    Write-Host "[OK] Python version $pythonVersion detected."
}

# 4. Check Tauri CLI installation
if (-not (Get-Command tauri -ErrorAction SilentlyContinue)) {
    Write-Host "[WARN] Tauri CLI is not installed. Installing via cargo..." -ForegroundColor Yellow
    cargo install tauri-cli
} else {
    $tauriVersion = tauri --version
    Write-Host "[OK] Tauri CLI version $tauriVersion detected."
}

# 5. Check PostgreSQL installation
if (-not (Get-Command psql -ErrorAction SilentlyContinue)) {
    Write-Host "[WARN] PostgreSQL is not installed. Please install PostgreSQL 14+ for full database support." -ForegroundColor Yellow
} else {
    $psqlVersion = psql --version
    Write-Host "[OK] PostgreSQL version $psqlVersion detected."
}

# 6. Check Redis installation
if (-not (Get-Command redis-server -ErrorAction SilentlyContinue)) {
    Write-Host "[WARN] Redis is not installed. Please install Redis for caching support." -ForegroundColor Yellow
} else {
    $redisVersion = redis-server --version
    Write-Host "[OK] Redis version $redisVersion detected."
}

Write-Host "\n[INFO] All required tools checked. Please review any warnings above."
Write-Host "[INFO] Next steps:"
Write-Host "  1. Configure environment variables (.env files)"
Write-Host "  2. Run backend and frontend setup scripts as documented"
Write-Host "  3. Use Docker Compose for hybrid LLM and service orchestration"
Write-Host "  4. Consult ENVIRONMENT_SETUP.md for detailed instructions"

Write-Host "--- TerraFusion Next-Gen Environment Initialization Complete ---" -ForegroundColor Cyan
