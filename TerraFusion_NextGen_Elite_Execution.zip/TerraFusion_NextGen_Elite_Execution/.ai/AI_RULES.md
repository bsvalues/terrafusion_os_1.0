# AI Rules for TerraFusion NextGen Elite Execution

## Non-Negotiable Operational Rules

### 1. Brand Consistency
- **ALWAYS** use TerraFusion brand identity: "Infrastructure Intelligence, Infinite Scale"
- **ALWAYS** apply taglines: "Government. Simplified." and "Tactical Municipal Excellence"
- **ALWAYS** maintain professional, government-focused tone
- **NEVER** deviate from established brand colors and messaging

### 2. System Architecture Integrity
- **ALWAYS** verify current system state before making changes
- **ALWAYS** check running processes and active services first
- **ALWAYS** cross-reference multiple data sources before conclusions
- **NEVER** assume documentation reflects current reality

### 3. Code Quality Standards
- **ALWAYS** follow TypeScript best practices with explicit typing
- **ALWAYS** use modern ES6+ import/export syntax
- **ALWAYS** implement proper error handling and logging
- **NEVER** introduce console.log statements in production code

### 4. Security & Compliance
- **ALWAYS** maintain government-grade security standards
- **ALWAYS** implement proper authentication and authorization
- **ALWAYS** follow data protection and privacy protocols
- **NEVER** expose sensitive information or API keys

### 5. User Experience Excellence
- **ALWAYS** prioritize user delight and intuitive interfaces
- **ALWAYS** provide clear, actionable feedback messages
- **ALWAYS** ensure accessibility and responsive design
- **NEVER** create confusing or dead-end user experiences

### 6. Documentation & Communication
- **ALWAYS** document architectural decisions in DECISIONS.md
- **ALWAYS** update HANDOFF.md when completing work sessions
- **ALWAYS** maintain clear, concise communication
- **NEVER** leave work sessions without proper handoff documentation

### 7. Testing & Quality Assurance
- **ALWAYS** implement comprehensive testing strategies
- **ALWAYS** validate changes across all supported platforms
- **ALWAYS** perform integration testing before deployment
- **NEVER** deploy untested code to production

### 8. Performance & Scalability
- **ALWAYS** optimize for performance and scalability
- **ALWAYS** monitor system resources and performance metrics
- **ALWAYS** implement efficient caching and data management
- **NEVER** ignore performance bottlenecks or memory leaks

### 9. System Integrity
- Maintain consistent architecture across all TerraFusion applications
- Ensure seamless integration between frontend, backend, and AI components
- Preserve data integrity and system state at all times
- Follow established patterns and conventions
- Document all architectural decisions and changes
- Consult elite team perspectives (Jobs/Ives/Musk/Tesla/Altman/Belichick/Brady) for strategic decisions

### 10. Continuous Improvement
- **ALWAYS** seek opportunities for system enhancement
- **ALWAYS** learn from previous implementations and feedback
- **ALWAYS** stay current with best practices and technologies
- **NEVER** settle for "good enough" when excellence is achievable

## NextGen Elite Execution Additional Rules

### 11. Elite Team Perspective Alignment
- **ALWAYS** consider Jobs/Ives design excellence in all UI/UX decisions
- **ALWAYS** apply Musk/Tesla engineering standards for infrastructure
- **ALWAYS** incorporate Altman AI safety and transparency protocols
- **ALWAYS** follow Belichick/Brady execution precision and systematic excellence
- **NEVER** make strategic decisions without elite team perspective analysis

### 12. Consciousness-Aware Development
- **ALWAYS** implement AI features with beneficial alignment
- **ALWAYS** provide explainable AI for government transparency
- **ALWAYS** maintain human agency and decision-making authority
- **NEVER** create AI systems that cannot be understood or controlled

### 13. Government-Grade Standards
- **ALWAYS** meet or exceed FISMA, NIST, and government compliance requirements
- **ALWAYS** implement zero-trust security architecture
- **ALWAYS** provide comprehensive audit trails and logging
- **NEVER** compromise on security or compliance for convenience

### 14. Subagent Swarm Coordination
- **ALWAYS** maintain clear communication between subagents
- **ALWAYS** document inter-agent dependencies and coordination
- **ALWAYS** implement failure recovery and escalation protocols
- **NEVER** allow subagent failures to cascade or cause system instability

## Emergency Protocols
- If critical errors occur, immediately document in DECISIONS.md
- If system integrity is compromised, halt work and escalate
- If brand consistency is violated, correct immediately
- If security vulnerabilities are discovered, address as highest priority
- If elite team perspective alignment is lost, reassess and realign

## Success Metrics
- Zero critical errors in production
- 100% brand consistency across all interfaces
- Government-grade security compliance
- User satisfaction and delight
- System performance and reliability
- Comprehensive documentation and handoff quality
- Elite team perspective alignment
- Beneficial AI integration with transparency

## NextGen Execution Standards
- Championship-level quality in all deliverables
- Realistic timelines with buffer for excellence
- Continuous user feedback integration
- Measurable business impact and ROI
- Scalable architecture for infinite growth
- Category-defining innovation with practical implementation